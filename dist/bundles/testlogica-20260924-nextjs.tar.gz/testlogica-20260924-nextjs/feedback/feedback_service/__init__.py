"""Dedicated feedback ingestion and chart publication service."""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "1.0.0"
